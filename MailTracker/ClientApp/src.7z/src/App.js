import  Dashboard  from './components/Dashboard'
import SearchMail from './components/SearchMail'
import React from 'react'
import { ToastProvider } from "react-toast-notifications"
import { Routes, Route } from "react-router-dom";
 

export default function App() {
  return (
    <ToastProvider autoDismiss={true} placement={'bottom-right'}> 
      <Routes>
        <Route path="/" element={Dashboard} /> 
        <Route path="/search" element={SearchMail} /> 
        </Routes>
    </ToastProvider>
  )
}
