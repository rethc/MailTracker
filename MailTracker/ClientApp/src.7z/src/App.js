import  Dashboard  from './components/Dashboard'
import React from 'react'

export default function App() {
  return (
    <Dashboard />
  )
}
